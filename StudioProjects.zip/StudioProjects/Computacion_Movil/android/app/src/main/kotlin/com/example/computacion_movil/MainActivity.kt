package com.example.computacion_movil

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
